import math
import time
import multiprocessing as mp
from config import STUDENT_ID, P_PHYS
from harness import emit_verify_tag

N = 8000
REPEATS = 3   


def work(i: int) -> float:
    K = 1 + (i // 40) ** 2
    x = 0.5
    acc = 0.0
    for _ in range(K):
        acc += math.sqrt(math.sin(x) * math.sin(x) + math.cos(x) * math.cos(x))
        x += 1e-3
    return acc


def w_block(t, p, tw):
    t0 = time.perf_counter()
    for i in range(N * t // p, N * (t + 1) // p):
        work(i)
    tw[t] = time.perf_counter() - t0


def w_cyclic(t, p, tw):
    t0 = time.perf_counter()
    for i in range(t, N, p):
        work(i)
    tw[t] = time.perf_counter() - t0


def w_dynamic(t, p, tw, counter, C):
    t0 = time.perf_counter()
    while True:
        with counter.get_lock():
            s = counter.value
            counter.value = s + C
        if s >= N:
            break
        for i in range(s, min(s + C, N)):
            work(i)
    tw[t] = time.perf_counter() - t0


def run(kind: str, C: int = 0):
    p = P_PHYS
    tw = mp.Array("d", p)
    if kind == "block":
        procs = [mp.Process(target=w_block, args=(t, p, tw)) for t in range(p)]
    elif kind == "cyclic":
        procs = [mp.Process(target=w_cyclic, args=(t, p, tw)) for t in range(p)]
    else:
        counter = mp.Value("i", 0)
        procs = [mp.Process(target=w_dynamic, args=(t, p, tw, counter, C)) for t in range(p)]
    t0 = time.perf_counter()
    for pr in procs:
        pr.start()
    for pr in procs:
        pr.join()
    wall = time.perf_counter() - t0
    times = list(tw)
    lam = max(times) / (sum(times) / p)
    return wall * 1e3, lam, times


def median_run(kind, C=0):
    res = sorted((run(kind, C) for _ in range(REPEATS)), key=lambda r: r[0])
    return res[REPEATS // 2]


if __name__ == "__main__":
    print(f"N={N}, p={P_PHYS}")
    print("| strategy | T_wall ms | lambda | per-worker times (s) |")
    print("|---|---|---|---|")
    wall_block, lam, tws = median_run("block")
    print(f"| block static | {wall_block:.0f} | {lam:.3f} | {[round(x,2) for x in tws]} |")
    wall, lam, tws = median_run("cyclic")
    print(f"| cyclic static | {wall:.0f} | {lam:.3f} | {[round(x,2) for x in tws]} |")

    best_C, best_wall = None, float("inf")
    for C in (1, 8, 64, 512):
        wall, lam, tws = median_run("dynamic", C)
        print(f"| dynamic C={C} | {wall:.0f} | {lam:.3f} | {[round(x,2) for x in tws]} |")
        if wall < best_wall:
            best_C, best_wall = C, wall

    print(f"\nC* = {best_C}")
    print(emit_verify_tag("PHASE4", STUDENT_ID, wall_block, best_wall))
