import time
import multiprocessing as mp
from config import STUDENT_ID
from harness import emit_verify_tag

if __name__ == "__main__":
    plog = mp.cpu_count()
    N = 10**6
    pc = time.perf_counter_ns
    pc() 
    t0 = pc()
    for _ in range(N):
        pc()
    avg_ns = (pc() - t0) / N
    print(f"mp.cpu_count() = {plog}")
    print(f"avg perf_counter_ns call latency = {avg_ns:.2f} ns")
    print(emit_verify_tag("PHASE0", STUDENT_ID, float(plog), avg_ns))
