
import multiprocessing as mp

STUDENT_ID = 230103251       
P_PHYS = 6           
P_LOG = mp.cpu_count()  
