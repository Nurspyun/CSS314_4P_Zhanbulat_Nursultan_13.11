import random
import multiprocessing as mp
from multiprocessing import shared_memory
from config import STUDENT_ID, P_PHYS
from harness import run_benchmark, emit_verify_tag

N = 256
BUF = 64 * 10**6
FLOPS_PER_WORKER = 6.0e7
NBYTES = N * N * 8



def copy_task(args):
    name_a, name_b, s, e = args
    sa = shared_memory.SharedMemory(name=name_a)
    sb = shared_memory.SharedMemory(name=name_b)
    mv_a, mv_b = sa.buf, sb.buf
    mv_a[s:e] = mv_b[s:e]
    sa.close()
    sb.close()



_src = "def fma_kernel(iters):\n"
for _i in range(16):
    _src += f"    a{_i} = {1.0 + 0.01 * _i}\n"
_src += "    b = 0.999999\n    c = 1e-7\n    for _ in range(iters):\n"
for _i in range(16):
    _src += f"        a{_i} = a{_i} * b + c\n"
_src += "    return " + " + ".join(f"a{_i}" for _i in range(16)) + "\n"
exec(_src, globals())

FMA_ITERS = int(FLOPS_PER_WORKER / (16 * 2))


def fma_task(iters):
    return fma_kernel(iters)



def gemm_task(args):
    variant, names, r0, r1, BS = args
    shms = [shared_memory.SharedMemory(name=n) for n in names]
    A, B, C = [s.buf.cast("d") for s in shms]
    try:
        if variant == 1:        
            for i in range(r0, r1):
                for j in range(N):
                    s = 0.0
                    for k in range(N):
                        s += A[i * N + k] * B[k * N + j]
                    C[i * N + j] = s
        elif variant == 2:      
            for i in range(r0, r1):
                rc = i * N
                for k in range(N):
                    aik = A[i * N + k]
                    rb = k * N
                    for j in range(N):
                        C[rc + j] += aik * B[rb + j]
        else:                   
            for ii in range(r0, r1, BS):
                imax = min(ii + BS, r1)
                for jj in range(0, N, BS):
                    jmax = min(jj + BS, N)
                    for kk in range(0, N, BS):
                        kmax = min(kk + BS, N)
                        for i in range(ii, imax):
                            rc = i * N
                            for k in range(kk, kmax):
                                aik = A[i * N + k]
                                rb = k * N
                                for j in range(jj, jmax):
                                    C[rc + j] += aik * B[rb + j]
    finally:
        for v in (A, B, C):
            v.release()
        for s in shms:
            s.close()


if __name__ == "__main__":
    p = P_PHYS
    with mp.Pool(processes=p) as pool:
        
        sa = shared_memory.SharedMemory(create=True, size=BUF)
        sb = shared_memory.SharedMemory(create=True, size=BUF)
        try:
            bounds = [(BUF * t // p, BUF * (t + 1) // p) for t in range(p)]
            tasks = [(sa.name, sb.name, s, e) for s, e in bounds]
            st = run_benchmark(lambda: pool.map(copy_task, tasks, chunksize=1), warmup=2, runs=7)
            T = st.median_ms / 1e3
            BW = 2 * 64e6 / (T * 1e9)
            print(f"BW_sustained = {BW:.2f} GB/s (median {st.median_ms:.1f} ms)")
        finally:
            sa.close(); sa.unlink()
            sb.close(); sb.unlink()

        st = run_benchmark(lambda: pool.map(fma_task, [FMA_ITERS] * p, chunksize=1), warmup=1, runs=5)
        T = st.median_ms / 1e3
        P_SUST = p * FLOPS_PER_WORKER / (T * 1e9)
        RIDGE = P_SUST / BW
        print(f"P_sustained = {P_SUST:.3f} GFLOP/s (median {st.median_ms:.1f} ms)")
        print(f"Ridge point I* = {RIDGE:.3f} FLOP/byte")

        
        shA = shared_memory.SharedMemory(create=True, size=NBYTES)
        shB = shared_memory.SharedMemory(create=True, size=NBYTES)
        shC = shared_memory.SharedMemory(create=True, size=NBYTES)
        names = (shA.name, shB.name, shC.name)
        Av, Bv, Cv = shA.buf.cast("d"), shB.buf.cast("d"), shC.buf.cast("d")
        try:
            random.seed(STUDENT_ID)
            for i in range(N * N):
                Av[i] = random.random()
                Bv[i] = random.random()
            rows = [(N * t // p, N * (t + 1) // p) for t in range(p)]

            def run_variant(v, BS=0):
                shC.buf[:NBYTES] = bytes(NBYTES)   # обнулить C
                pool.map(gemm_task, [(v, names, r0, r1, BS) for r0, r1 in rows], chunksize=1)

            def gflops(ms):
                return 2 * N**3 / (ms / 1e3 * 1e9)

            WU, RN = 1, 5
            s1 = run_benchmark(lambda: run_variant(1), WU, RN)
            g1 = gflops(s1.median_ms)
            C1 = Cv.tolist()
            s2 = run_benchmark(lambda: run_variant(2), WU, RN)
            g2 = gflops(s2.median_ms)
            C2 = Cv.tolist()
            print(f"\nV1 naive : {s1.median_ms:.0f} ms, {g1:.4f} GFLOP/s")
            print(f"V2 i-k-j : {s2.median_ms:.0f} ms, {g2:.4f} GFLOP/s")
            print(f"max|C2-C1| = {max(abs(a-b) for a, b in zip(C2, C1)):.2e}")

            print("\n| BS | W_tile KB | I_tiled F/B | median ms | GFLOP/s | max|C3-C2| |")
            print("|---|---|---|---|---|---|")
            best_bs, best_g = None, -1.0
            for BS in [8, 16, 32, 64, 96, 128]:
                s3 = run_benchmark(lambda: run_variant(3, BS), WU, RN)
                g3 = gflops(s3.median_ms)
                err = max(abs(a - b) for a, b in zip(Cv.tolist(), C2))
                assert err < 1e-9, f"verification failed for BS={BS}: {err}"
                wtile = 3 * BS * BS * 8 / 1024
                print(f"| {BS} | {wtile:.1f} | {BS/12:.2f} | {s3.median_ms:.0f} | {g3:.4f} | {err:.1e} |")
                if g3 > best_g:
                    best_bs, best_g = BS, g3

            print(f"\nBS* = {best_bs}, W_tile = {3*best_bs*best_bs*8/1024:.1f} KB, "
                  f"I_tiled = {best_bs/12:.2f} F/B, GFLOP/s(V3) = {best_g:.4f}")
            print(f"Roofline attainable at I_tiled: min(P, BW*I) = "
                  f"{min(P_SUST, BW * best_bs / 12):.3f} GFLOP/s  (measured {best_g:.4f})")
            print()
            print(emit_verify_tag("PHASE3", STUDENT_ID, g1, best_g))
        finally:
            for v in (Av, Bv, Cv):
                v.release()
            for s in (shA, shB, shC):
                s.close(); s.unlink()
