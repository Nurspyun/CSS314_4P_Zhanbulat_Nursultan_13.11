import math
import time
import statistics
import multiprocessing as mp
from config import STUDENT_ID, P_PHYS, P_LOG
from harness import emit_verify_tag

WARMUP, RUNS = 1, 5


def stage_a(n: int) -> float:
    """Serial stage: 10 sin/sqrt ops per element."""
    acc = 0.0
    for i in range(n):
        x = i * 1e-3
        for _ in range(5):
            x = math.sqrt(math.sin(x) + 2.0)   
        acc += x
    return acc


def stage_b(n: int) -> float:
    """Parallel stage: 30 FMA/trig ops per element, no shared writes."""
    acc = 0.0
    for i in range(n):
        x = i * 1e-6
        for _ in range(10):
            x = x * 0.999 + 0.001
            x = math.sin(x)      
            x = x * 1.001 + 0.5
        acc += x
    return acc


def trial(pool, p: int, N: int):
    t0 = time.perf_counter()
    stage_a(int(0.05 * N))
    t_a = time.perf_counter() - t0
    chunks = [N // p + (1 if i < N % p else 0) for i in range(p)]
    pool.map(stage_b, chunks, chunksize=1)
    total = time.perf_counter() - t0
    return t_a, total


def bench(p: int, N: int):
    with mp.Pool(processes=p) as pool:      
        pool.map(stage_b, [1] * p)          
        res = [trial(pool, p, N) for _ in range(WARMUP + RUNS)][WARMUP:]
    return (statistics.median(r[0] for r in res),
            statistics.median(r[1] for r in res))


if __name__ == "__main__":
    
    N = 1_200_000
    print(f"## Strong scaling (N={N})")
    print("| p | T_p s | S_p | E_p |")
    print("|---|---|---|---|")
    Ts, tA1 = {}, None
    for p in range(1, P_LOG + 1):
        tA, T = bench(p, N)
        Ts[p] = T
        if p == 1:
            tA1 = tA
        S = Ts[1] / T
        print(f"| {p} | {T:.3f} | {S:.2f} | {S/p:.2f} |")
    S_strong = {p: Ts[1] / Ts[p] for p in Ts}
    s = tA1 / Ts[1]
    print(f"\nserial fraction s = T_A(1)/T_1 = {s:.4f};  Amdahl cap S_inf = {1/s:.2f}")
    print(f"Observed S_strong(P_log={P_LOG}) = {S_strong[P_LOG]:.2f}")

    print("\nMarginal speedup dS(p-1 -> p):")
    for p in range(2, P_LOG + 1):
        mark = "  <-- P_phys -> P_phys+1" if p == P_PHYS + 1 else ""
        print(f"  {p-1}->{p}: {S_strong[p] - S_strong[p-1]:+.3f}{mark}")

    
    N0 = 200_000
    print(f"\n## Weak scaling (N0={N0} per worker)")
    print("| p | N(p) | T_p s | E_weak | alpha | S_Gustafson |")
    print("|---|---|---|---|---|---|")
    Tw1, SG = None, {}
    for p in range(1, P_LOG + 1):
        tA, T = bench(p, p * N0)
        if p == 1:
            Tw1 = T
        alpha = tA / T
        SG[p] = p - alpha * (p - 1)
        print(f"| {p} | {p*N0} | {T:.3f} | {Tw1/T:.2f} | {alpha:.4f} | {SG[p]:.2f} |")

    print()
    print(emit_verify_tag("PHASE2", STUDENT_ID, S_strong[P_LOG], SG[P_LOG]))
