import ctypes
import multiprocessing as mp
from multiprocessing import shared_memory
from config import STUDENT_ID, P_PHYS, P_LOG
from harness import run_benchmark, emit_verify_tag

M = 16_000_000          
WARMUP, RUNS = 1, 5     


def fs_worker(shm_name: str, slot_idx: int, iters: int) -> None:
    shm = shared_memory.SharedMemory(name=shm_name)
    arr = (ctypes.c_uint64 * 512).from_buffer(shm.buf)
    acc = arr[slot_idx]
    for i in range(iters):
        acc = (acc * 6364136223846793005 + (i | 1)) & 0xFFFFFFFFFFFFFFFF
        arr[slot_idx] = acc  
    del arr
    shm.close()


def run_once(p: int, stride: int, name: str) -> None:
    iters = M // p
    procs = [mp.Process(target=fs_worker, args=(name, t * stride, iters)) for t in range(p)]
    for pr in procs:
        pr.start()
    for pr in procs:
        pr.join()


def bench(p, stride, name):
    return run_benchmark(lambda: run_once(p, stride, name), warmup=WARMUP, runs=RUNS)


def p_list():
    ps, p = [], 1
    while p <= P_LOG:
        ps.append(p)
        p *= 2
    if ps[-1] != P_LOG:
        ps.append(P_LOG)
    return ps


def karp_flatt(S, p):
    return (1 / S - 1 / p) / (1 - 1 / p)


if __name__ == "__main__":
    shm = shared_memory.SharedMemory(create=True, size=4096)
    try:
        print(f"## Stride sweep (p={P_PHYS})")
        print("| stride | bytes | median ms | IQR ms | Mops/s |")
        print("|---|---|---|---|---|")
        med = {}
        for stride in [1, 2, 4, 8, 16, 32]:
            if P_PHYS * stride > 512:
                print(f"| {stride} | {stride*8} | skipped (out of 4096 B) | | |")
                continue
            s = bench(P_PHYS, stride, shm.name)
            med[stride] = s.median_ms
            mops = (M / 1e6) / (s.median_ms / 1e3)
            print(f"| {stride} | {stride*8} | {s.median_ms:.1f} | {s.iqr_ms:.1f} | {mops:.1f} |")

        for stride in (1, 16):
            print(f"\n## Process scaling, stride={stride}")
            print("| p | median ms | S_p | E_p | Karp-Flatt e(p) |")
            print("|---|---|---|---|---|")
            T = {}
            for p in p_list():
                if p * stride > 512:
                    continue
                T[p] = bench(p, stride, shm.name).median_ms
                S = T[1] / T[p]
                e = f"{karp_flatt(S, p):.4f}" if p >= 2 else "-"
                print(f"| {p} | {T[p]:.1f} | {S:.2f} | {S/p:.2f} | {e} |")

        print()
        print(emit_verify_tag("PHASE1", STUDENT_ID, med[1], med[16]))
    finally:
        shm.close()
        shm.unlink()
